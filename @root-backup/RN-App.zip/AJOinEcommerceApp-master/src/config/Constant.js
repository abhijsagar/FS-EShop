export const Color = {
  primary: "#4a06c9",
  white: "#ffffff",
  black: "#000000",
};
